import pandas as pd
import numpy as np
import os

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor, GradientBoostingRegressor
from sklearn.neighbors import KNeighborsRegressor

from xgboost import XGBRegressor
from lightgbm import LGBMRegressor

# -----------------------------
# LOAD DATA
# -----------------------------
hist = pd.read_csv("tables/historical_cleaned.csv")
syn = pd.read_csv("tables/synthetic_cleaned.csv")

df = pd.concat([hist, syn], ignore_index=True)

features = ["thickness","holes","aspect_ratio","mat_tg","pth_req","max_ol_copper"]
target = "yield_percent"

df = df[features + [target]].dropna()

X = df[features]
y = df[target]

# -----------------------------
# SPLIT
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# -----------------------------
# MODELS
# -----------------------------
models = {
    "ExtraTrees": ExtraTreesRegressor(),
    "RandomForest": RandomForestRegressor(),
    "GradientBoosting": GradientBoostingRegressor(),
    "XGBoost": XGBRegressor(verbosity=0),
    "LightGBM": LGBMRegressor(),
    "KNN_k15": KNeighborsRegressor(n_neighbors=15),
    "KNN_k9": KNeighborsRegressor(n_neighbors=9),
    "KNN_k5": KNeighborsRegressor(n_neighbors=5)
}

results = []

# -----------------------------
# TRAIN + METRICS
# -----------------------------
for name, model in models.items():
    model.fit(X_train, y_train)

    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)

    train_mae = mean_absolute_error(y_train, y_train_pred)
    test_mae = mean_absolute_error(y_test, y_test_pred)

    train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
    test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))

    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)

    cv_scores = -cross_val_score(model, X, y, scoring='neg_root_mean_squared_error', cv=5)
    cv_mean = cv_scores.mean()
    cv_std = cv_scores.std()

    results.append([name, train_mae, test_mae, train_rmse, test_rmse, train_r2, test_r2, cv_mean, cv_std])

# -----------------------------
# RESULTS DF
# -----------------------------
results_df = pd.DataFrame(results, columns=[
    "model","train_mae","test_mae","train_rmse","test_rmse","train_r2","test_r2","cv_rmse_mean","cv_rmse_std"
])

results_df.to_csv("output_sheet/model_comparison.csv", index=False)

# -----------------------------
# BEST MODEL
# -----------------------------
best_model_name = "ExtraTrees"
best_model = models[best_model_name]

# -----------------------------
# INPUT CASE
# -----------------------------
input_case = pd.DataFrame([{
    "thickness":1.6,
    "holes":12000,
    "aspect_ratio":3.2,
    "mat_tg":140,
    "pth_req":20,
    "max_ol_copper":74
}])

predicted_yield = best_model.predict(input_case)[0]

# -----------------------------
# SIMILAR CASES
# -----------------------------
top_cases = pd.read_csv("tables/top_similar_cases.csv")

best_nearby = top_cases["yield_percent"].max()
stack_hi = top_cases.iloc[0].get("stack_hi", "N/A")

# -----------------------------
# SAVE EXCEL REPORT
# -----------------------------
with pd.ExcelWriter("output_sheet/yield_recommendation_with_used_data.xlsx") as writer:
    hist.to_excel(writer, sheet_name="Historical_Data_Used", index=False)
    syn.to_excel(writer, sheet_name="Synthetic_Data_Used", index=False)
    top_cases.to_excel(writer, sheet_name="Recommendation", index=False)





import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# -----------------------------
# GLOBAL STYLE
# -----------------------------
plt.rcParams.update({
    "figure.figsize": (10, 6),
    "font.size": 12,
    "axes.titlesize": 14,
    "axes.labelsize": 12,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10
})

def save_plot(path):
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches='tight')  # 🔥 prevents cutting
    plt.close()

# -----------------------------
# PREDICTIONS FOR BEST MODEL
# -----------------------------
y_pred = best_model.predict(X_test)

# -----------------------------
# 1. ACTUAL VS PREDICTED
# -----------------------------
plt.figure()
sns.scatterplot(x=y_test, y=y_pred)

# diagonal reference line
plt.plot([y_test.min(), y_test.max()],
         [y_test.min(), y_test.max()],
         linestyle='--')

plt.xlabel("Actual Yield")
plt.ylabel("Predicted Yield")
plt.title("Actual vs Predicted")

save_plot("output_figures/best_model_actual_vs_predicted.png")

# -----------------------------
# 2. RESIDUAL PLOT
# -----------------------------
residuals = y_test - y_pred

plt.figure()
sns.scatterplot(x=y_pred, y=residuals)

plt.axhline(0, linestyle='--')
plt.xlabel("Predicted Yield")
plt.ylabel("Residuals")
plt.title("Residual Plot")

save_plot("output_figures/best_model_residual_plot.png")

# -----------------------------
# 3. CORRELATION HEATMAP
# -----------------------------
plt.figure(figsize=(12, 8))

sns.heatmap(df.corr(),
            cmap="coolwarm",
            annot=True,
            fmt=".2f",
            annot_kws={"size": 8})

plt.title("Correlation Heatmap")

plt.subplots_adjust(left=0.2, bottom=0.2)

save_plot("output_figures/correlation_heatmap.png")

# -----------------------------
# 4. FEATURE IMPORTANCE (ExtraTrees)
# -----------------------------
plt.figure()

importances = best_model.feature_importances_
sorted_idx = np.argsort(importances)

sns.barplot(
    x=importances[sorted_idx],
    y=np.array(features)[sorted_idx]
)

plt.xlabel("Importance")
plt.title("ExtraTrees Feature Importance")

save_plot("output_figures/ExtraTrees_feature_importance.png")

# -----------------------------
# 5. MODEL COMPARISON GRAPHS
# -----------------------------
for col in ["test_mae", "test_rmse", "test_r2", "cv_rmse_mean"]:
    plt.figure()

    sns.barplot(x=results_df["model"], y=results_df[col])

    plt.xticks(rotation=45, ha='right')
    plt.xlabel("Model")
    plt.ylabel(col)
    plt.title(f"{col} Comparison")

    plt.subplots_adjust(bottom=0.3)

    save_plot(f"output_figures/model_comparison_{col}.png")

# -----------------------------
# 6. YIELD DISTRIBUTION
# -----------------------------
plt.figure()

sns.histplot(df["yield_percent"], bins=20, kde=True)

plt.xlabel("Yield %")
plt.title("Yield Distribution")

save_plot("output_figures/yield_distribution.png")

# -----------------------------
# 7. SIMILAR CASE YIELDS
# -----------------------------
plt.figure()

sns.barplot(
    x=top_cases.index.astype(str),
    y=top_cases["yield_percent"]
)

plt.xticks(rotation=45)
plt.xlabel("Case Index")
plt.ylabel("Yield %")
plt.title("Top Similar Case Yields")

save_plot("output_figures/top_similar_case_yields.png")

# -----------------------------
# 8. SIMILARITY PLOT
# -----------------------------
if "similarity" in top_cases.columns:
    plt.figure()

    sns.barplot(
        x=top_cases.index.astype(str),
        y=top_cases["similarity"]
    )

    plt.xticks(rotation=45)
    plt.xlabel("Case Index")
    plt.ylabel("Similarity")
    plt.title("Top Similar Case Similarity")

    save_plot("output_figures/top_similar_case_similarity.png")

# -----------------------------
# 9. PREDICTED vs NEARBY
# -----------------------------
plt.figure()

sns.barplot(
    x=["Predicted", "Best Nearby"],
    y=[predicted_yield, best_nearby]
)

plt.ylabel("Yield %")
plt.title("Predicted vs Best Nearby")

save_plot("output_figures/predicted_vs_best_nearby.png")

print("\n✅ All plots generated perfectly in output_figures/")

# -----------------------------
# PRINT FINAL REPORT
# -----------------------------
print("\nPCB Yield Model Comparison and Recommendation Report")
print("="*65)
print("Workbook: yield_recommendation_with_used_data.xlsx")
print(f"Rows used: {len(df)}")
print("Historical sheet: Historical_Data_Used")
print("Synthetic sheet: Synthetic_Data_Used")
print("Recommendation sheet: Recommendation")

print("\nCore inputs:")
for f in features:
    print(f"  {f}: {f}")

print(f"Target: {target}")

print("\nModel comparison:")
print(results_df.to_string(index=False))

print(f"\nBest predictive model: {best_model_name}")

print("\nInput case:")
for col in input_case.columns:
    print(f"  {col}: {input_case.iloc[0][col]}")

print(f"\nPredicted yield using best model: {predicted_yield:.4f}")
print(f"Best observed nearby achievable yield: {best_nearby:.4f}")

print("\nRecommended process outputs from best nearby case:")
print(f"  stack_hi: {stack_hi}")